﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace GIP_Versie2._3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        Speler objPlayer;
        LevelElementen objLevel;
        Gereedschap objTools;
        public Zeis objZeis;
        public Mandje objMandje;
        DispatcherTimer _gameTmr;
        public List<Plant> veld;

        public MainWindow()
        {
            InitializeComponent();
            objLevel = new LevelElementen(objCanvas);
            objLevel.Achtergrond();

            objPlayer = new Speler(objCanvas);
            objTools = new Gereedschap(objCanvas);
            objZeis = new Zeis(objCanvas);
            objMandje = new Mandje(objCanvas);
            veld = new List<Plant>();

            objCanvas.Children.Add(objPlayer.Player);
            objTools.ToolsStart();

            _gameTmr = new DispatcherTimer();
            _gameTmr.Interval = TimeSpan.FromSeconds(300);
            _gameTmr.Tick += GameStop;
            _gameTmr.Start();
        }

        //Opgeroepen als er een toets word ingedrukt
        private void Game_KeyDown(object sender, KeyEventArgs e)
        {
            objCanvas.Children.Remove(objPlayer.Player);

            //Test welke toets
            switch (e.Key)
            {
                case Key.Left:
                    objPlayer.LeftArrowPressed();
                    objTools.WatDragen(objPlayer.Xpos, objPlayer.Ypos, objZeis);
                    objZeis.PlantInMandje(objPlayer.Xpos, objPlayer.Ypos, veld);
                    break;
                case Key.Right:
                    objPlayer.RightArrowPressed();
                    objTools.WatDragen(objPlayer.Xpos, objPlayer.Ypos, objZeis);
                    objZeis.PlantInMandje(objPlayer.Xpos, objPlayer.Ypos, veld);
                    break;
                case Key.Up:
                    objPlayer.UpArrowPressed();
                    objTools.WatDragen(objPlayer.Xpos, objPlayer.Ypos, objZeis);
                    objZeis.PlantInMandje(objPlayer.Xpos, objPlayer.Ypos, veld);
                    break;
                case Key.Down:
                    objPlayer.DownArrowPressed();
                    objTools.WatDragen(objPlayer.Xpos, objPlayer.Ypos, objZeis);
                    objZeis.PlantInMandje(objPlayer.Xpos, objPlayer.Ypos, veld);
                    break;
                case Key.Space:
                    objTools.Pakken(objPlayer.Xpos, objPlayer.Ypos);
                    objTools.WatDragen(objPlayer.Xpos, objPlayer.Ypos, objZeis);
                    break;
                case Key.X:
                    objTools.Gebruiken(objPlayer.Xpos, objPlayer.Ypos, veld, objMandje, objZeis);
                    objZeis.PlantInMandje(objPlayer.Xpos, objPlayer.Ypos, veld);
                    TxtB_ScoreDisplay.Text = "Score : " + objMandje.Score;
                    break;
            }

            objCanvas.Children.Add(objPlayer.Player);
        }

        //Na 5min stopt het spel en gaan we naar het eind scherm
        public void GameStop(object sender, EventArgs e)
        {
            _gameTmr.Stop();
            Window Eindscherm = new EindScherm(objMandje.Score);
            Eindscherm.Show();
            this.Close();
        }

    }
}
