﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace GIP_Versie2._3
{
    public class Plant : LevelElementen
    {
        //klassevariablen
        protected DispatcherTimer _objTimer1;
        protected DispatcherTimer _objTimer2;
        protected Image _oogst = new Image();
        protected int _waarde;
        protected double _groeitijd1 = 10;
        protected double _groeitijd2 = 10;
        protected bool _inBezit;

        Image _groei = new Image();        
        Random objRandom = new Random((int)(DateTime.Now.Ticks & 0x7FFFFFFF));

        int[] _zeldzaamheid = new int[] { 33, 99, 199, 333, 501, 731, 1000};

        //constructor
        public Plant(Canvas pCanvas) : base(pCanvas)
        {
            _objCanvas = pCanvas;
            _grootte = 64;

            _objTimer1 = new DispatcherTimer();
            _objTimer1.Interval = TimeSpan.FromSeconds(_groeitijd1);
            _objTimer1.Tick += GroeiFase1;

            _objTimer2 = new DispatcherTimer();
            _objTimer2.Interval = TimeSpan.FromSeconds(_groeitijd2);
        }

        //eigenschappen
        public bool InBezit
        {
            get
            {
                return _inBezit;
            }

            set
            {
                _inBezit = value;
            }
        }

        public int Waarde
        {
            get
            {
                return _waarde;
            }
        }

        public Image Oogst
        {
            get
            {
                return _oogst;
            }
        }

        public double GroeiTijd1
        {
            get
            {
                return _groeitijd1;
            }

            set
            {
                _groeitijd1 = value;
            }
        }

        public double GroeiTijd2
        {
            get
            {
                return _groeitijd2;
            }

            set
            {
                _groeitijd2 = value;
            }
        }

        //methodes

        //Word opgeroepen bij gebruik zaadje
        public void inPlanten(int pSpelerX, int pSpelerY, List<Plant> veld)
        {
            _x_pos = pSpelerX;
            _y_pos = pSpelerY;

            _groei.Source = new BitmapImage(new Uri("Images/Groei1.png", UriKind.Relative));
            _groei.Margin = new Thickness(_x_pos, _y_pos, 0, 0);
            _groei.Width = _grootte;
            _groei.Height = _grootte;
            _objCanvas.Children.Add(_groei);

            _objTimer2.Tick += (sender, e) => { GroeiFase2(sender, e, veld); };
            _objTimer1.Start();

        }

        //na 15 seconden is de groei al halfweg --> nieuwe afbeelding
        public void GroeiFase1(object sender, EventArgs e)
        {
            _objCanvas.Children.Remove(_groei);
            _groei.Source = new BitmapImage(new Uri("Images/Groei2.png", UriKind.Relative));
            _groei.Margin = new Thickness(_x_pos, _y_pos, 0, 0);
            _groei.Width = _grootte;
            _groei.Height = _grootte;
            _objCanvas.Children.Add(_groei);

            _objTimer1.Stop();

            _objTimer2.Start();
        }

        //15sec later, groei is compleet
        public void GroeiFase2(object sender, EventArgs e, List<Plant> veld)
        {
            _objCanvas.Children.Remove(_groei);
            //aantalGegroeid optellen voor UpdateGroei() in Gereedschap.cs -- TIJDELIJKE OPLOSSING||WERKT NIET
            OogstToevoegen(_x_pos, _y_pos, veld);
            _objTimer2.Stop();
        }

        //toevoegen aan lijst --> loopt mis, lijst reset zichzelf (uitleg in zeis.cs.Oogsten() )
        public void OogstToevoegen(int ZaadjeX, int ZaadjeY, List<Plant> veld)
        {
            //Willekeurige plant kiezen en toevoegen
            switch (KiesPlant())
            {
                case PlantType.Pumpkin:
                    Pumpkin objPumpkin = new Pumpkin(_objCanvas, ZaadjeX, ZaadjeY);
                    veld.Add(objPumpkin);
                    break;
                case PlantType.Cauliflower:
                    Cauliflower objCauliflower = new Cauliflower(_objCanvas, ZaadjeX, ZaadjeY);
                    veld.Add(objCauliflower);
                    break;
                case PlantType.Lettuce:
                    Lettuce objLettuce = new Lettuce(_objCanvas, ZaadjeX, ZaadjeY);
                    veld.Add(objLettuce);
                    break;
                case PlantType.Eggplant:
                    Eggplant objEggplant = new Eggplant(_objCanvas, ZaadjeX, ZaadjeY);
                    veld.Add(objEggplant);
                    break;
                case PlantType.Blueberry:
                    Blueberry objBlueberry = new Blueberry(_objCanvas, ZaadjeX, ZaadjeY);
                    veld.Add(objBlueberry);
                    break;
                case PlantType.Tomatoes:
                    Tomatoes objTomatoes = new Tomatoes(_objCanvas, ZaadjeX, ZaadjeY);
                    veld.Add(objTomatoes);
                    break;
                case PlantType.Potatoe:
                    Potatoe objPatatje = new Potatoe(_objCanvas, ZaadjeX, ZaadjeY);
                    veld.Add(objPatatje);
                    break;
            }
        }

        public PlantType KiesPlant()
        {
            PlantType _planttype = 0;         // start at first one
            int randomValue = objRandom.Next(1000);
            while (_zeldzaamheid[(int)_planttype] <= randomValue)
            {
                _planttype++;         // next loot type
            }
            return _planttype;
        }

        public enum PlantType
        {
            Pumpkin, Cauliflower, Lettuce, Eggplant, Blueberry, Tomatoes,
            Potatoe, Default
        }
    }
}
