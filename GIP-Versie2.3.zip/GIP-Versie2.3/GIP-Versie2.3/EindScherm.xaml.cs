﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace GIP_Versie2._3
{
    /// <summary>
    /// Interaction logic for EindScherm.xaml
    /// </summary>
    public partial class EindScherm : Window
    {
        int eindScore;
        public EindScherm(int pScore)
        {
            InitializeComponent();
            eindScore = pScore;
            //Scores tonen
            //Declaratie
            string Data = "datasource=localhost;database=dbfarmrush;port=3306;username=root;password=";
            int i = 1;

            MySqlConnection mysql_conn = new MySqlConnection(Data);
            MySqlCommand mysql_cmd = new MySqlCommand();
            MySqlDataReader mysql_dr;

            //Eigenschappen
            mysql_cmd.Connection = mysql_conn;
            mysql_cmd.CommandText = "SELECT Username, Score FROM tblscores";

            //Verwerking

            mysql_conn.Open();
            mysql_dr = mysql_cmd.ExecuteReader();

            while(mysql_dr.Read() && i < 4)
            {
                string strScores = "";
                strScores = mysql_dr["Username"].ToString() + ": " + mysql_dr["Score"].ToString();
                TxtB_scores.Text += strScores + "\n";
                i++;
            }
            TxtB_scores.Text += "Jouw score: " + eindScore;

            mysql_conn.Close();
        }

        //Score doorgeven
        private void Btn_Bevestig_Click(object sender, RoutedEventArgs e)
        {
            //Declaratie
            string Data = "datasource=localhost;database=dbfarmrush;port=3306;username=root;password=";
            DateTime huidigetijd = new DateTime();
            MySqlConnection score_conn = new MySqlConnection(Data);
            MySqlConnection passeer_conn = new MySqlConnection(Data);
            MySqlCommand score_cmd = new MySqlCommand();
            MySqlDataReader score_dr;

            //Eigenschappen
            score_cmd.Connection = score_conn;

            //Verwerking

            score_conn.Open();
            score_cmd.CommandText = "SELECT Username FROM tblgebruikers WHERE Username = '" + TxtB_Username.Text + "'";
            score_dr = score_cmd.ExecuteReader();

            if (!score_dr.Read())
            {
                MessageBox.Show("Username niet gevonden, probeer opnieuw of maak een account aan op de site.");
            }
            else 
            {
                passeer_conn.Open();
                score_cmd.Connection = passeer_conn;
                score_cmd.CommandText = "INSERT INTO tblscores (Username, Score, Time) VALUES ('" + TxtB_Username.Text + "','" + eindScore + "', '"+ huidigetijd.Date.ToLocalTime().ToString() +"')";
                score_cmd.ExecuteNonQuery();
                passeer_conn.Close();
                MessageBox.Show("Score toegevoeg! Bekijk ze op de site.");

            }

            score_conn.Close();
        }
    }
}
