﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace GIP_Versie2._3
{
    public class Mandje : Gereedschap
    {
        //klasse eigenschappen
        int _score = 0;

        //constructor
        public Mandje(Canvas pCanvas) : base(pCanvas)
        {

        }

        //eigenschappen
        public int Score
        {
            get
            {
                return _score;
            }
        }

        //methoden
        //Zaadje verwijderen, score optellen
        public void Verkopen(List<Plant> veld)
        {
            for (int i = 0; i < veld.Count; i++)
            {
                if (veld[i].InBezit)
                {
                    _objCanvas.Children.Remove(veld[i].Oogst);
                    _score += veld[i].Waarde;
                    veld.RemoveAt(i);
                }
            }
        }
    }
}
